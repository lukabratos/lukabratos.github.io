import UIKit

enum UserProfileOperations {
    case updateProfilePicture(URL)
    case updateDateOfBirth(Int)
}

// UserProfileOperations extension which conforms to the `Codable` protocol
extension UserProfileOperations: Codable {
    // Define coding keys which will be used as the authoritative list
    // of properties that must be included when instances of a codable
    // type are encoded or decoded.
    enum CodingKeys: CodingKey {
        case profilePictureURL
        case dobTimestamp
    }
    
    // `CodingError` is used to communicate any errors
    // that can happen when encoding or decoding.
    enum CodingError: Error {
        case message(String)
    }
    
    // Conform to the `Decodable` protocol by implementing its required
    // initializer, [init(from:)](https://developer.apple.com/documentation/swift/decodable/2894081-init):
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        // Decode the value of `profilePictureURL` from the decoder.
        if let profilePictureURL = try? container.decode(URL.self, forKey: .profilePictureURL) {
            self = .updateProfilePicture(profilePictureURL)
            return
        }
        if let dob = try? container.decode(Int.self, forKey: .dobTimestamp) {
            self = .updateDateOfBirth(dob)
            return
        }
        // If the keys used in serialized data format don't match with ones specified
        // in `CodingKeys`, throw an error.
        throw CodingError.message("Error: \(dump(container))")
    }
    
    // Conform to the `Encodable` protocol by implementing its required
    // method, [encode(to:)](https://developer.apple.com/documentation/swift/encodable/2893603-encode):
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .updateProfilePicture(let url):
            try container.encode(url, forKey: .profilePictureURL)
        case .updateDateOfBirth(let dob):
            try container.encode(dob, forKey: .dobTimestamp)
        }
    }
}

// Encoding
let encoder = JSONEncoder()
var profilePictureOperation = UserProfileOperations.updateProfilePicture(URL(string: "https://via.placeholder.com/150/1ee8a4")!)
let operationData = try! encoder.encode(profilePictureOperation)
let jsonString = String(data: operationData, encoding: .utf8)!

// Decoding
let decoder = JSONDecoder()
let profilePictureJSONString = """
{"profilePictureURL":"https://via.placeholder.com/150/1ee8a4"}
"""
profilePictureOperation = try! decoder.decode(UserProfileOperations.self, from: profilePictureJSONString.data(using: .utf8)!)

// Persisting values atomically to the file
let johnProfilePictureURL = UserProfileOperations.updateProfilePicture(URL(string: "https://via.placeholder.com/150/197d29")!)
let johnDateOfBirthOperation = UserProfileOperations.updateDateOfBirth(1561825023)

let kateProfilePictureURL = UserProfileOperations.updateProfilePicture(URL(string: "https://via.placeholder.com/150/c70a4d")!)
let kateDateOfBirthOperation = UserProfileOperations.updateDateOfBirth(733622400)

let timProfilePictureURL = UserProfileOperations.updateProfilePicture(URL(string: "https://via.placeholder.com/150/56acb2")!)
let timDateOfBirthOperation = UserProfileOperations.updateDateOfBirth(586915200)

let operations = [johnProfilePictureURL, johnDateOfBirthOperation, kateProfilePictureURL, kateDateOfBirthOperation, timProfilePictureURL, timDateOfBirthOperation]
let jsonEncoder = JSONEncoder()
let data = try! jsonEncoder.encode(operations)
let url = URL(fileURLWithPath: "operations")
try data.write(to: url, options: .atomic)

// Reading values from the file
let operationsData = try! Data(contentsOf: url)
let jsonDecoder = JSONDecoder()
let operationsArray = try! jsonDecoder.decode([UserProfileOperations].self, from: operationsData)
